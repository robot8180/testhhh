﻿export default function Privacy() {
  return (
    <section className="container py-16">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-3xl font-extrabold">Privacy Policy</h1>
        <p className="mt-4 text-muted-foreground">Last updated: September 2025</p>

        <p className="mt-6">At QuickROFix (operating as RO Service) we respect your privacy and are committed to protecting the personal information you share with us. This Privacy Policy explains how we collect, use, disclose and protect your information when you use our website or services.</p>

        <h2 className="mt-6 text-xl font-semibold">Information We Collect</h2>
        <ul className="mt-3 list-disc pl-6 text-sm text-muted-foreground space-y-2">
          <li>Contact details you provide (name, phone number, email) when booking or contacting us.</li>
          <li>Service details such as device model, service requests, and feedback submitted to help us deliver service.</li>
          <li>Usage and technical data collected automatically (IP address, browser, pages visited) to improve the site and prevent abuse.</li>
        </ul>

        <h2 className="mt-6 text-xl font-semibold">How We Use Your Information</h2>
        <ul className="mt-3 list-disc pl-6 text-sm text-muted-foreground space-y-2">
          <li>To respond to your booking requests and communicate about service appointments.</li>
          <li>To process payments and manage any post-service support or warranty claims.</li>
          <li>To improve our website, services and customer experience; to analyze usage patterns.</li>
          <li>To comply with legal obligations and to prevent fraudulent or abusive activity.</li>
        </ul>

        <h2 className="mt-6 text-xl font-semibold">Sharing & Disclosure</h2>
        <p className="mt-3 text-sm text-muted-foreground">We do not sell your personal information. We may share information with:</p>
        <ul className="mt-3 list-disc pl-6 text-sm text-muted-foreground space-y-2">
          <li>Trusted service partners who assist with delivery of service (technicians, logistics) on a need-to-know basis.</li>
          <li>Payment processors when you make a payment.</li>
          <li>Law enforcement or regulators when required by law.</li>
        </ul>

        <h2 className="mt-6 text-xl font-semibold">Your Choices</h2>
        <p className="mt-3 text-sm text-muted-foreground">You can choose not to provide certain personal information, but this may limit our ability to provide services. You may also opt out of marketing communications by contacting us or using an unsubscribe option where available.</p>

        <h2 className="mt-6 text-xl font-semibold">Data Security</h2>
        <p className="mt-3 text-sm text-muted-foreground">We apply reasonable administrative, technical and physical safeguards to protect personal information. No online system can be completely secure, so please also take care when sharing sensitive information.</p>

        <h2 className="mt-6 text-xl font-semibold">Retention</h2>
        <p className="mt-3 text-sm text-muted-foreground">We retain personal information for as long as necessary to provide services, comply with legal obligations and resolve disputes.</p>

        <h2 className="mt-6 text-xl font-semibold">Contact Us</h2>
        <p className="mt-3 text-sm text-muted-foreground">If you have questions about this Privacy Policy or wish to exercise your rights, email us at <a href="mailto:info@bookroservice.com" className="text-primary">info@bookroservice.com</a> or call <a href="tel:+918062180546" className="text-primary">08062180546</a>.</p>

        <p className="mt-6 text-sm text-muted-foreground">By using our site and services you agree to the terms of this policy.</p>
      </div>
    </section>
  );
}
