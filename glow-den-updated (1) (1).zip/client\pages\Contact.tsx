﻿import { useState } from "react";
import { toast } from "@/components/ui/use-toast";

export default function Contact() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  function validate() {
    if (!name.trim()) return "Please enter your name.";
    if (!phone.trim()) return "Please enter your phone number.";
    if (!/^\+?[0-9\s()-]{7,20}$/.test(phone)) return "Please enter a valid phone number.";
    if (!email.trim()) return "Please enter your email.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Please enter a valid email.";
    if (!message.trim()) return "Please enter a message.";
    return null;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const err = validate();
    if (err) {
      toast({ title: "Validation error", description: err });
      return;
    }
    setSubmitting(true);
    const payload = { name, phone, email, message, createdAt: new Date().toISOString() };
    try {
      // Attempt to POST to /api/contact if a backend exists. Fallback to client-side success.
      try {
        await fetch("/api/contact", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } catch (err) {
        // ignore network errors for now
        console.warn("Contact submit (local fallback)", err);
      }

      toast({ title: "Message sent", description: "Thank you â€” we will contact you shortly." });
      setName("");
      setPhone("");
      setEmail("");
      setMessage("");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="container py-20">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-3xl font-extrabold">Contact Us</h1>
        <p className="mt-2 text-muted-foreground">Reach out for bookings, AMC, or any questions. Call us at <a href="tel:+918062180546" className="text-primary">08062180546</a>.</p>

        <form className="mt-8 grid gap-4" onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className="flex flex-col">
              <span className="text-sm font-medium">Full name</span>
              <input className="mt-2 rounded-md border px-3 py-2" value={name} onChange={(e) => setName(e.target.value)} />
            </label>
            <label className="flex flex-col">
              <span className="text-sm font-medium">Phone</span>
              <input className="mt-2 rounded-md border px-3 py-2" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </label>
          </div>

          <label className="flex flex-col">
            <span className="text-sm font-medium">Email</span>
            <input className="mt-2 rounded-md border px-3 py-2" value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>

          <label className="flex flex-col">
            <span className="text-sm font-medium">Message</span>
            <textarea rows={5} className="mt-2 rounded-md border px-3 py-2" value={message} onChange={(e) => setMessage(e.target.value)} />
          </label>

          <div className="mt-4">
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground shadow hover:bg-primary/90 disabled:opacity-60"
            >
              {submitting ? "Sending..." : "Send Message"}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}
