﻿export default function Terms() {
  return (
    <section className="container py-16">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-3xl font-extrabold">Terms & Conditions</h1>
        <p className="mt-4 text-muted-foreground">Last updated: September 2025</p>

        <p className="mt-6">These Terms & Conditions govern your use of QuickROFix (RO Service) website and services. By accessing or using our website or booking services you agree to these terms.</p>

        <h2 className="mt-6 text-xl font-semibold">Services</h2>
        <p className="mt-3 text-sm text-muted-foreground">We provide doorstep RO installation, repair, maintenance and annual maintenance contracts (AMCs). Service availability, pricing and timelines are subject to change and may vary by location.</p>

        <h2 className="mt-6 text-xl font-semibold">Bookings & Payments</h2>
        <ul className="mt-3 list-disc pl-6 text-sm text-muted-foreground space-y-2">
          <li>Bookings can be made via phone or online. You must provide accurate contact information.</li>
          <li>Prices shown are for reference. Final charges for parts and specific repairs will be confirmed by the technician.</li>
          <li>Payment methods and terms will be displayed at checkout where applicable. Refunds and cancellations follow our refund policy.</li>
        </ul>

        <h2 className="mt-6 text-xl font-semibold">Customer Responsibilities</h2>
        <p className="mt-3 text-sm text-muted-foreground">Customers must provide safe access to the equipment and truthful information about the RO unit. Deliberate damage, misrepresentation or obstruction of the technician may result in additional charges.</p>

        <h2 className="mt-6 text-xl font-semibold">Warranties & Liability</h2>
        <p className="mt-3 text-sm text-muted-foreground">We provide services using reasonable care and skill. Parts installed may carry manufacturer warranties. To the fullest extent permitted by law, QuickROFix's liability for any claim relating to services is limited to the amount paid for the relevant service.</p>

        <h2 className="mt-6 text-xl font-semibold">Intellectual Property</h2>
        <p className="mt-3 text-sm text-muted-foreground">All content on the website including text, logos and images is owned or licensed by QuickROFix and may not be used without permission.</p>

        <h2 className="mt-6 text-xl font-semibold">Changes to Terms</h2>
        <p className="mt-3 text-sm text-muted-foreground">We may update these terms from time to time. We will post updates on our website; your continued use of services constitutes acceptance of the updated terms.</p>

        <h2 className="mt-6 text-xl font-semibold">Contact</h2>
        <p className="mt-3 text-sm text-muted-foreground">For questions about these Terms, contact us at <a href="mailto:info@bookroservice.com" className="text-primary">info@bookroservice.com</a> or call <a href="tel:+918062180546" className="text-primary">08062180546</a>.</p>
      </div>
    </section>
  );
}
