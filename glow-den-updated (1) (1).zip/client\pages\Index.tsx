import { CheckCircle2, Droplet, Wrench, ShieldCheck, BadgePercent, WrenchIcon, Hammer, Cog, Phone, XCircle } from "lucide-react";
import React, { useEffect, useState } from "react";
import ReviewsCarousel from "@/components/site/ReviewsCarousel";

const Bullet = ({ children }: { children: React.ReactNode }) => (
  <li className="flex items-start gap-3">
    <CheckCircle2 className="mt-0.5 h-5 w-5 text-green-600" />
    <span>{children}</span>
  </li>
);

const planButtonClass = "inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 min-w-[120px] font-semibold text-primary-foreground shadow hover:bg-primary/90 transform transition-all duration-300 hover:scale-105 animate-pulse hover:animate-none motion-reduce:animate-none";

export default function Index() {
  return (
    <div>
      {/* Hero */}
      <section className="relative">
        <div className="container grid gap-8 py-8 md:py-12 md:grid-cols-2 md:items-center">
          <div>
            <p className="text-sm font-semibold text-accent">at Just</p>
            <h1 className="mt-2 text-4xl font-extrabold tracking-tight md:text-5xl">
              Get <span className="text-primary">RO Service Technician</span>
              <br /> at Your Doorstep
            </h1>
            <div className="mt-3 flex items-baseline gap-3 text-2xl font-black">
              <span className="line-through text-muted-foreground/60">₹ 399</span>
              <span className="text-accent">₹ 299*</span>
            </div>
            <ul className="mt-6 space-y-3 text-base">
              <Bullet>Includes Full Water Purifier Checkup</Bullet>
              <Bullet>Service & spare part charges extra as per rate card</Bullet>
              <Bullet>Save Up To 50% on Annual Maintenance (AMC)</Bullet>
              <Bullet>Branded & Non-Branded RO Authentic Service</Bullet>
              <Bullet>Installation, Repair & Relocation Services</Bullet>
            </ul>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="tel:+918062180546"
                className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground shadow hover:bg-primary/90"
              >
                <Phone className="h-5 w-5" /> Book/Call Now
              </a>
              <a
                href="tel:+918062180546"
                className="inline-flex items-center gap-2 rounded-full border border-primary px-6 py-3 font-semibold text-primary hover:bg-primary/5"
              >
                For Booking Call +918062180546
              </a>
            </div>
          </div>
          <div className="relative">
            <div className="w-full rounded-2xl overflow-hidden bg-gradient-to-r from-primary/6 to-accent/6">
              <img src="https://cdn.builder.io/api/v1/image/assets%2F149006f4100f464682006e677a9bbb4c%2Fe10cd6a67a52405ba85b0c3a7fa6135c?format=webp&width=800" alt="Water purifier" className="w-full h-44 md:h-72 lg:h-96 object-contain" />
            </div>
            <div className="pointer-events-none absolute -right-2 -top-3 hidden select-none md:block">
              <span className="rotate-12 text-2xl font-bold text-sky-600">Stay Healthy</span>
            </div>
          </div>
        </div>
{/* Live counters */}
        <div className="mx-auto mt-6 max-w-6xl">
          <div className="rounded-2xl bg-white/5 backdrop-blur-md p-4 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div>
                <div className="text-sm text-muted-foreground">Total Services</div>
                <LiveChangingNumber base={124500} label="Services Done" />
              </div>
              <div className="hidden sm:block border-l h-8 w-px border-muted/30" />
              <div>
                <div className="text-sm text-muted-foreground">ROs Installed</div>
                <ContinuousCounter base={47000} label="Total Installed" />
              </div>
              <div className="hidden sm:block border-l h-8 w-px border-muted/30" />
              <div>
                <div className="text-sm text-muted-foreground">Active AMCs</div>
                <LiveChangingNumber base={8600} label="Active AMC" />
              </div>
            </div>
            <div>
              <a href="tel:+918062180546" className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-2 font-semibold text-white shadow hover:bg-accent/90">Talk to Sales</a>
            </div>
          </div>
        </div>

        <div className="bg-primary/90 text-primary-foreground">
          <div className="container grid gap-6 py-4 md:grid-cols-3">
            <Feature icon={<BadgePercent />} title="Save More" subtitle="on AMC Package" />
            <Feature icon={<WrenchIcon />} title="RO Installation" subtitle="Maintenance, Repair, Service" />
            <Feature icon={<ShieldCheck />} title="Specially Trained" subtitle="Technicians" />
          </div>
        </div>
      </section>

      {/* Problems */}
      <section className="container py-16 md:py-24">
        <h2 className="text-center text-3xl font-extrabold tracking-tight text-primary md:text-4xl">
          Facing the Below Problems?
        </h2>
        <div className="mx-auto mt-10 grid max-w-5xl grid-cols-1 gap-8 sm:grid-cols-2">
          {problems.map((p, i) => (
            <div
              key={p.title}
              className="flex items-start gap-4 rounded-xl bg-white p-5 shadow-sm ring-1 ring-border transform transition-all duration-500 hover:-translate-y-1 hover:shadow-lg reveal"
              style={{ animationDelay: `${i * 120}ms` }}
            >
              <Droplet className="h-6 w-6 text-accent" />
              <div>
                <h3 className="font-semibold text-foreground">{p.title}</h3>
                <p className="text-sm text-muted-foreground">{p.subtitle}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Why choose us */}
      <section className="bg-muted/30 py-16 md:py-24">
        <div className="container">
          <h2 className="text-center text-3xl font-extrabold tracking-tight md:text-4xl">Why Choose us?</h2>
          <p className="mx-auto mt-4 max-w-3xl text-center text-muted-foreground">
            Home Water Purifier Service Center stands out in Hyderabad for transparent pricing, trained technicians and
            quick doorstep service.
          </p>

          {/* Animated stat */}
          <div className="mx-auto mt-6 flex items-center justify-center gap-6">
            <StatCounter value={47000} label="ROs Installed" />
            <div className="text-sm text-muted-foreground">|</div>
            <div className="text-sm text-muted-foreground">16+ Years Experience</div>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {why.map((w) => (
              <div key={w.title} className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-border">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                  {w.icon}
                </div>
                <h3 className="font-semibold">{w.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{w.subtitle}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Plans summary */}
      <section className="container py-16 md:py-24">
        <h2 className="text-center text-3xl font-extrabold tracking-tight md:text-4xl">Subscription Plans</h2>
        <p className="mx-auto mt-4 max-w-2xl text-center text-muted-foreground">
          Pick a plan that matches your family size. Save with our AMCs and keep water pure year-round.
        </p>

        {/* Benefits highlight */}
        <div className="mx-auto mt-6 max-w-4xl rounded-2xl bg-gradient-to-r from-primary/10 to-accent/10 p-6 shadow-md ring-1 ring-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-lg font-semibold">Why AMC? Benefits of subscribing</div>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-3"><CheckCircle2 className="h-5 w-5 text-green-600" /> <span className="font-medium">Priority service & faster response</span></li>
              <li className="flex items-start gap-3"><ShieldCheck className="h-5 w-5 text-sky-600" /> <span className="font-medium">Discount on spare parts</span></li>
              <li className="flex items-start gap-3"><BadgePercent className="h-5 w-5 text-amber-500" /> <span className="font-medium">Free periodic health check</span></li>
            </ul>
          </div>
          <div className="text-right">
            <a href="tel:+918062180546" className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-3 font-semibold text-white shadow animate-pulse hover:animate-none">Call to Subscribe</a>
          </div>
        </div>

        <div className="mx-auto mt-10 grid max-w-6xl gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {plans.map((pl) => (
            <div key={pl.name} className={`relative rounded-2xl bg-white p-6 shadow-sm ring-1 ring-border transform transition-all duration-300 hover:scale-105 hover:shadow-lg hover:ring-2 ${pl.popular ? 'border-primary' : ''}`}>
              {pl.popular && (
                <div className="absolute -left-3 -top-3 rotate-12 rounded-md bg-primary px-3 py-1 text-xs font-bold text-primary-foreground shadow-lg animate-bounce motion-reduce:animate-none">
                  <span className="inline-flex items-center gap-1">
                    <span className="hidden sm:inline">ðŸ”¥</span>
                    Most Popular
                  </span>
                </div>
              )}

              <div className="flex items-baseline justify-between">
                <h3 className="text-lg font-semibold">{pl.name}</h3>
                <div className="flex flex-col items-end">
                  {pl.originalPrice && <span className="text-sm line-through text-muted-foreground/70">{pl.originalPrice}</span>}
                  <div className={`text-2xl font-extrabold ${pl.popular ? 'text-accent animate-pulse' : 'text-accent'}`}>{pl.price}</div>
                </div>
              </div>
              <ul className="mt-4 space-y-2 text-sm">
                {pl.coverage.map((c) => {
                  const notCovered = /not covered/i.test(c);
                  return (
                    <li key={c} className="flex items-start gap-2">
                      {notCovered ? (
                        <XCircle className="mt-0.5 h-4 w-4 text-red-500" />
                      ) : (
                        <CheckCircle2 className="mt-0.5 h-4 w-4 text-green-600" />
                      )}
                      <span className={notCovered ? 'opacity-70' : ''}>{c}</span>
                    </li>
                  );
                })}
              </ul>

              <div className="mt-6 flex items-center justify-between">
                <a href="tel:+918062180546" className={planButtonClass}>Book Now</a>
                {pl.popular && (
                  <div className="text-sm font-semibold text-accent bg-accent/10 px-4 py-2 rounded-md animate-pulse motion-reduce:animate-none flex items-center gap-2">
                    <span className="inline-block rounded-full bg-accent/20 px-2 py-0.5 text-xs font-bold">-20%</span>
                    <span>Save up to 20% with this plan</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <a href="tel:+918062180546" className="rounded-full bg-accent px-8 py-3 font-semibold text-white shadow hover:bg-accent/90">
            Call to Subscribe
          </a>
        </div>
      </section>

      {/* Reviews */}
      <section className="container py-16 md:py-24">
        <h2 className="text-center text-3xl font-extrabold tracking-tight md:text-4xl">What our customers say</h2>
        <p className="mx-auto mt-4 max-w-2xl text-center text-muted-foreground">Real reviews from customers who booked our service.</p>
        <div className="mx-auto mt-8">
          <ReviewsCarousel reviews={reviews} />
        </div>
      </section>
    </div>
  );
}

function Feature({ icon, title, subtitle }: { icon: React.ReactNode; title: string; subtitle: string }) {
  return (
    <div className="flex items-center gap-4">
      <div className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-primary-foreground/15 text-primary-foreground">
        {icon}
      </div>
      <div>
        <div className="text-sm font-semibold">{title}</div>
        <div className="text-xs opacity-90">{subtitle}</div>
      </div>
    </div>
  );
}

const problems = [
  { title: "RO Making Beep Sound", subtitle: "Service or part replacement may be required" },
  { title: "LCD Indicators Not Displayed", subtitle: "Check electricals and sensors" },
  { title: "TDS Level Increased", subtitle: "Membrane or filters may need service" },
  { title: "Less or No Water", subtitle: "Low flow or tank not filling" },
  { title: "Water Leakage / Bad Taste", subtitle: "Pipes, fittings or filters issue" },
  { title: "Vibrations or Noise", subtitle: "Pump or mounting check" },
];

const why = [
  { title: "Unmatched Professional Service", subtitle: "Specially trained technicians at affordable price", icon: <Wrench className="h-6 w-6" /> },
  { title: "Transparent Charges", subtitle: "Approve before any part replacement", icon: <BadgePercent className="h-6 w-6" /> },
  { title: "Affordable AMCs", subtitle: "Save with regular and timely service", icon: <Hammer className="h-6 w-6" /> },
  { title: "16+ Years Experience", subtitle: "Installed 47,000+ RO in Hyderabad", icon: <Cog className="h-6 w-6" /> },
];

function StatCounter({ value, label }: { value: number; label: string }) {
  const [num, setNum] = useState(0);
  const raf = React.useRef<number | null>(null);
  const containerRef = React.useRef<HTMLDivElement | null>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    if (started) return;
    const el = containerRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.2) {
            setStarted(true);
            obs.disconnect();
          }
        });
      },
      { threshold: [0.2] }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    const duration = 2400;
    let startTime: number | null = null;

    function easeOutCubic(t: number) {
      return 1 - Math.pow(1 - t, 3);
    }

    function step(timestamp: number) {
      if (startTime === null) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = easeOutCubic(progress);
      const current = Math.floor(eased * value);
      setNum(current);
      if (progress < 1) {
        raf.current = requestAnimationFrame(step);
      } else {
        setNum(value);
      }
    }

    raf.current = requestAnimationFrame(step);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
  }, [started, value]);

  return (
    <div className="text-center" ref={containerRef}>
      <div className="text-2xl font-extrabold text-primary">{num.toLocaleString()}+</div>
      <div className="text-sm text-muted-foreground">{label}</div>
    </div>
  );
}

function LiveChangingNumber({ base, label }: { base: number; label?: string }) {
  const [display, setDisplay] = useState(base);
  const [bump, setBump] = useState(false);

  useEffect(() => {
    let mounted = true;
    function tick() {
      if (!mounted) return;
      // increase by a small percentage of base (between 0.02% and 0.08%) to keep increments modest and monotonic
      const pct = Math.random() * (0.0008 - 0.0002) + 0.0002;
      const inc = Math.max(1, Math.floor(base * pct));
      setDisplay((d) => d + inc);
      // trigger small pop animation
      setBump(true);
      window.setTimeout(() => setBump(false), 360);
    }
    const id = setInterval(tick, 2400);
    return () => {
      mounted = false;
      clearInterval(id);
    };
  }, [base]);

  return (
    <div>
      <div className={`text-2xl font-extrabold text-primary ticker-number ${bump ? 'animate' : ''}`}>{display.toLocaleString()}</div>
      {label && <div className="text-xs text-muted-foreground">{label}</div>}
    </div>
  );
}

function ContinuousCounter({ base, label }: { base: number; label?: string }) {
  // show a smooth counting once, then hold value
  return <StatCounter value={base} label={label || ''} />;
}

const plans = [
  { name: "AMC Plan 1", price: "Rs. 999", originalPrice: "Rs. 1,299", coverage: ["Includes Service", "Filter (Not Covered)", "Membrane (Not Covered)", "Electrical Parts (Not Covered)", "Faulty Parts (Not Covered)"] },
  { name: "AMC Plan 2", price: "Rs. 2,499", originalPrice: "Rs. 2,999", coverage: ["Includes Service", "Electrical Parts Covered", "Filter (Not Covered)", "Membrane (Not Covered)", "Faulty Parts (Not Covered)"] },
  { name: "AMC Plan 3", price: "Rs. 3,499", originalPrice: "Rs. 3,899", coverage: ["Includes Service", "Filter Covered", "Electrical Parts (Not Covered)", "Membrane (Not Covered)", "Faulty Parts (Not Covered)"] },
  { name: "AMC Plan 4", price: "Rs. 4,499", originalPrice: "Rs. 4,999", coverage: ["Includes Service", "Filter Covered", "Membrane Covered", "Electrical Parts (Not Covered)", "Faulty Parts (Not Covered)"] },
  { name: "AMC Plan 5", price: "Rs. 5,499", originalPrice: "Rs. 6,199", coverage: ["Includes Service", "Electrical Parts Covered", "Filter Covered", "Membrane Covered", "Faulty Parts (Not Covered)"] },
  { name: "AMC Plan 6", price: "Rs. 6,999", originalPrice: "Rs. 8,999", coverage: ["Includes Service", "Filter Covered", "Electrical Parts Covered", "Membrane Covered", "Faulty Parts Covered"], popular: true },
];

const reviews = [
  { name: "Suresh K.", location: "HITEC City, Hyderabad", avatar: "/avatar1.svg", rating: 5, text: "Quick and professional service. Technician fixed our RO in under 30 minutes. Highly recommend!" },
  { name: "Neha R.", location: "Secunderabad", avatar: "/avatar2.svg", rating: 4, text: "Good pricing and transparent charges. The team replaced the filters quickly." },
  { name: "Amit P.", location: "Madhapur", avatar: "/avatar3.svg", rating: 5, text: "Excellent AMC plans. Regular servicing solved our water taste issue." },
  { name: "Priya S.", location: "Banjara Hills", avatar: "/avatar1.svg", rating: 5, text: "Very professional and punctual team. They explained the issue clearly and left the place clean. Highly satisfied with the service." },
];
