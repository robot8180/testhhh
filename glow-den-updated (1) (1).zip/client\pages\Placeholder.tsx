import { Link } from "react-router-dom";

export default function Placeholder({ title }: { title: string }) {
  return (
    <section className="container py-24">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">{title}</h1>
        <p className="mt-4 text-muted-foreground">
          This page is not filled yet. Tell me what you want here and I will build it next.
        </p>
        <div className="mt-8">
          <Link className="text-primary hover:underline" to="/">Return Home</Link>
        </div>
      </div>
    </section>
  );
}
