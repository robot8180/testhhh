﻿import React, { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

export default function BookingPrompt() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [time, setTime] = useState("");
  const [slots, setSlots] = useState<number>(8);
  const mounted = useRef(true);

  useEffect(() => {
    // reduce slots slowly to create urgency
    const id = setInterval(() => {
      setSlots((s) => Math.max(1, s - (Math.random() > 0.85 ? 1 : 0)));
    }, 7000);
    return () => {
      clearInterval(id);
      mounted.current = false;
    };
  }, []);

  function openModal() {
    setOpen(true);
  }

  function closeModal() {
    setOpen(false);
  }

  function validatePhone(p: string) {
    const digits = p.replace(/[^0-9]/g, "");
    return digits.length >= 7 && digits.length <= 15;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !validatePhone(phone)) {
      toast.error("Please enter a valid name and phone number");
      return;
    }

    // simulate sending booking request
    toast.success("Thanks! Your booking request is received. We'll call you shortly.");
    // Optionally clear form
    setName("");
    setPhone("");
    setTime("");
    setOpen(false);
  }

  return (
    <>
      {/* Sticky booking banner (visible on all sizes) */}
      <div style={{ position: 'fixed', left: '8px', right: '8px', bottom: 'calc(env(safe-area-inset-bottom, 12px) + 8px)', zIndex: 99999, display: 'flex', justifyContent: 'center', pointerEvents: 'auto' }}>
        <div className="w-full max-w-[1100px] rounded-lg bg-gradient-to-r from-accent to-primary p-3 shadow-xl ring-1 ring-border text-white flex items-center justify-between gap-3 overflow-visible" style={{ paddingBottom: 'calc(0.75rem + env(safe-area-inset-bottom, 0px))' }}>
          <div className="flex items-center gap-3">
            <div className="rounded-full bg-white/10 p-2 sm:p-3">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 16.92V21a1 1 0 0 1-1.11 1 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2 3.11 1 1 0 0 1 3 2h4.09a1 1 0 0 1 1 .75c.12.56.37 1.46.8 2.6a1 1 0 0 1-.24 1L7.91 8.91a16 16 0 0 0 6 6l1.56-1.56a1 1 0 0 1 1-.24c1.13.43 2.03.68 2.59.8a1 1 0 0 1 .75 1V21z" fill="currentColor"/>
              </svg>
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate">Limited slots â€” Book a call now</div>
              <div className="text-xs opacity-90 truncate">AMC plans from <span className="font-bold">Rs. 999</span>. <span className="ml-2 inline-block bg-white/20 px-2 py-0.5 rounded text-xs">Only {slots} slots left</span></div>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <a href="tel:+918062180546" className="rounded-full bg-white/90 px-3 py-2 text-sm font-semibold text-accent shadow hover:scale-105 transform transition">Call</a>
            <button onClick={openModal} className="rounded-full border border-white/30 bg-white/10 px-3 py-2 text-sm font-semibold hover:bg-white/20 transition">Book</button>
          </div>
        </div>
      </div>

      {/* Modal */}
      {open && (
        <div className="fixed inset-0 z-60 flex items-center justify-center px-4">
          <div className="absolute inset-0 bg-black/40" onClick={closeModal} />
          <div className="relative max-w-md w-full rounded-xl bg-background p-6 shadow-lg ring-1 ring-border">
            <h3 className="text-lg font-bold text-foreground">Book a Call</h3>
            <p className="mt-1 text-sm text-muted-foreground">Enter your details and we'll call you within 24 hours.</p>
            <form onSubmit={handleSubmit} className="mt-4 grid gap-3">
              <label className="text-sm text-muted-foreground">Full name</label>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="w-full rounded-md border px-3 py-2 bg-input text-foreground" />

              <label className="text-sm text-muted-foreground">Phone number</label>
              <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. +919912345678" className="w-full rounded-md border px-3 py-2 bg-input text-foreground" />

              <label className="text-sm text-muted-foreground">Preferred time (optional)</label>
              <input value={time} onChange={(e) => setTime(e.target.value)} placeholder="e.g. Tomorrow 10-12" className="w-full rounded-md border px-3 py-2 bg-input text-foreground" />

              <div className="mt-2 flex items-center justify-between">
                <button type="submit" className="inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-white">Request Call</button>
                <button type="button" onClick={() => { navigator.clipboard?.writeText('+918062180546'); toast('Number copied to clipboard'); }} className="text-sm text-muted-foreground">Copy number</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
